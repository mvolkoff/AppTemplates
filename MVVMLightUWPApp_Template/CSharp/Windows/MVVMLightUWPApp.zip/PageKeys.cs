﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    public static class PageKeys
    {
        public const string HOME = "HomePage";
        public const string SETTINGS = "SettingsPage";
        public const string ABOUT = "AboutPage";
    }
}
